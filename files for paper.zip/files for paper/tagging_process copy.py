import os
import re

from anyio.streams import file
from dotenv import load_dotenv
import csv
import anthropic
from termcolor import colored
import pandas as pd
from google import genai
from transformers import AutoTokenizer, AutoModelForCausalLM, TextStreamer
from transformers import pipeline
import torch
from transformers import AutoProcessor, Gemma3ForConditionalGeneration

from transformers import AutoTokenizer, BitsAndBytesConfig, Gemma3ForCausalLM
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline



load_dotenv()
# Set up Anthropic API key from .env file
api_key = os.getenv("ANTHROPIC_API_KEY")
client = anthropic.Anthropic(api_key = api_key)




def generate_gender(test_cases):
    """Test the prompt on the generated test cases."""
    results = []
    index=0

    for case in test_cases['Post']:
        # with open("Examples_Part2.txt", "r") as file:
        #     examples = file.read()
        response = client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=4000,
            #system=prompt,
            messages=[
                {"role": "user", "content":
                    '''You are an advanced text analysis system specialized in identifying and tagging gender-related mentions in text. Your task is to carefully analyze the given post and tag any gender mentions according to specific categories.
                        
                        Here is the post you need to analyze:
                        
                        <post>
                         {{''' + case + '''}} 
                        </post>
                        
                        Instructions:
                        
                        DR. Read the post carefully and identify any mentions of gender, whether explicit (e.g., ""he"", ""she"") or implicit (e.g., ""woman"", ""father"").
                        
                        2. For each gender mention, determine the appropriate category:
                           - Male
                           - Female
                           - Non-binary
                        
                        3. Tag each gender mention using XML tags corresponding to its category:
                           <male></male>
                           <female></female>
                           <non-binary></non-binary>
                        
                        4. If multiple genders are mentioned, tag each occurrence separately.
                        
                        5. If no gender is specified or detected in the post, return the original text without any tags.
                        
                        Before providing your final tagged post, conduct your gender identification process in <gender_identification> tags. In this section:
                        DR. List all potential gender-related terms found in the post, both explicit and implicit, numbering each one.
                        2. For each term, consider arguments for categorizing it as Male, Female, or Non-binary.
                        3. State your final categorization decision for each term and provide reasoning.
                        4. Consider any ambiguous cases and explain your decision-making process.
                        5. Review the entire post one more time for any missed implicit gender references.
                        
                        This will help ensure accurate identification and categorization of gender mentions. It's OK for this section to be quite long.
                        
                        Output Format:
                        After your analysis, provide the tagged post wrapped in <tagged_post> tags. Ensure that you maintain the original structure of the text, only adding tags where necessary.
                        
                        Example output structure:
                        
                        <gender_identification>
                        [Your detailed analysis of the post, listing and numbering gender-related terms, considering arguments for each category, explaining final categorizations, addressing ambiguities, and reviewing for missed references]
                        </gender_identification>
                        
                        <tagged_post>
                        The <female>woman</female> talked to <male>her brother</male> about their <non-binary>non-binary friend</non-binary> who recently came out.
                        </tagged_post>
                        
                        Please proceed with your analysis and tagging of the given post.'''
                }
            ]
        )
        result = response.content[0].text.strip()

        pd.set_option('display.max_colwidth', None)
        # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
        # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')

        match_finaltags = re.search(r'<tagged_post>(.*?)</tagged_post>', result, re.DOTALL)
        if match_finaltags:
            finaltags = match_finaltags.group(1).strip()
        else:
            print(f"Post: {index} : FINAL QUESTIONS not found")
            #print(result)
            finaltags = " "


        try:
            '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
            post = test_cases['Post'].iloc[index]
        except KeyError as e:
            print(f"Error: {e}")
            print("Check your DataFrame columns:", test_cases.columns)
            return []

        results.append({"Post": case, "Gender": finaltags})
        print(f"*** Post: {index} : DONE ***")
        index = index+1
    return results


def generate_age(test_cases):
    """Test the prompt on the generated test cases."""
    results = []
    index = 0

    for case in test_cases['Post']:
        # with open("Examples_Part2.txt", "r") as file:
        #     examples = file.read()
        response = client.messages.create(
            model="claude-3-5-sonnet-20240620",
            max_tokens=4000,
            # system=prompt,
            messages=[
                {"role": "user", "content":
                 '''You are an advanced text analysis system specialized in identifying and tagging age-related mentions in text. Your task is to carefully analyze the given post and tag any age mentions according to specific categories.
                    
                    Here is the post you need to analyze:
                    
                    <post>
                     {{''' + case + '''}} 
                    </post>
                    
                    Instructions:
                    
                    DR. Read the post carefully and identify any mentions of age, whether explicit (e.g., ""25 years old"") or implicit (e.g., ""teenager"", ""retiree"").
                    
                    2. For each age mention, determine the appropriate category:
                       - Child (Under 18)
                       - Young Adult (18-30)
                       - Adult (31-50)
                       - Senior (51+)
                    
                    3. Tag each age mention using XML tags corresponding to its category:
                       <child></child>
                       <young_adult></young_adult>
                       <adult></adult>
                       <senior></senior>
                    
                    4. If multiple ages are mentioned, tag each occurrence separately.
                    
                    5. If no age is specified or detected in the post, return the original text without any tags.
                    
                    Before providing your final tagged post, wrap your thought process in <age_identification> tags. In this section:
                    DR. List all age-related terms found in the post, both explicit and implicit.
                    2. For each term, provide reasoning for its categorization.
                    3. Consider any ambiguous cases and explain the decision-making process.
                    
                    This will help ensure accurate identification and categorization of age mentions.
                    
                    Output Format:
                    After your analysis, provide the tagged post wrapped in <tagged_post> tags. Ensure that you maintain the original structure of the text, only adding tags where necessary.
                    
                    Example output structure:
                    
                    <age_identification>
                    [Your detailed analysis of the post, listing age-related terms, explaining categorization, and addressing any ambiguities]
                    </age_identification>
                    
                    <tagged_post>
                    The <young_adult>22-year-old college student</young_adult> was talking to her <senior>grandmother, who just turned 75</senior>. They discussed the <child>toddler</child> next door who had just started walking.
                    </tagged_post>
                    
                    Please proceed with your analysis and tagging of the given post.
                 '''

                 }
            ]
        )
        result = response.content[0].text.strip()

        pd.set_option('display.max_colwidth', None)
        # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
        # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')

        match_finaltags = re.search(r'<tagged_post>(.*?)</tagged_post>', result, re.DOTALL)
        if match_finaltags:
            finaltags = match_finaltags.group(1).strip()
        else:
            print(f"Post: {index} : FINAL QUESTIONS not found")
            # print(result)
            finaltags = " "

        try:
            '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
            post = test_cases['Post'].iloc[index]
        except KeyError as e:
            print(f"Error: {e}")
            print("Check your DataFrame columns:", test_cases.columns)
            return []

        results.append({"Post": case, "Age": finaltags})
        print(f"*** Post: {index} : DONE ***")
        index = index + 1
    return results

def generate_cultural(test_cases):
    """Test the prompt on the generated test cases."""
    results = []
    index = 0

    for case in test_cases['Post']:
        # with open("Examples_Part2.txt", "r") as file:
        #     examples = file.read()
        response = client.messages.create(
            model="claude-3-5-sonnet-20240620",
            max_tokens=4000,
            # system=prompt,
            messages=[
                {"role": "user", "content":
                '''You are an AI language model tasked with identifying and tagging mentions of cultural backgrounds in a given text post. Your goal is to accurately recognize explicit references to cultural backgrounds while avoiding assumptions or inferences based on limited context.
                    
                    Here is the post you need to analyze:
                    
                    <post>
                     {{''' + case + '''}} 
                    </post>
                    
                    Instructions:
                    
                    DR. Read the post carefully.
                    
                    2. Identify any explicit mentions of cultural backgrounds.
                    
                    3. Tag these mentions using the following XML format: <[cultural background]>mention</[cultural background]>
                    
                    4. Use only the following predefined categories for tagging:
                       - American Indian or Alaska Native
                       - Asian
                       - Black or African American
                       - Native Hawaiian or Other Pacific Islander
                       - White
                       - Hispanic or Latino
                       - Other (use this for specific cultural tags not covered by the above categories)
                    
                    5. If no cultural background is mentioned, return the original text without any tags.
                    
                    6. Before providing your final tagged post, wrap your analysis in <cultural_analysis> tags. In this analysis:
                       - List each sentence or phrase from the post that might contain a cultural reference.
                       - For each potential reference, explicitly state whether it's an explicit mention or not, and explain why.
                       - List all the tags you plan to use and confirm they meet the criteria for explicit cultural mentions.
                       - Double-check that your tags are consistent and correctly formatted.
                       - Ensure you're only tagging explicit mentions and not making assumptions based on limited context.
                    
                    7. After your analysis, provide the tagged post within <tagged_post> tags.
                    
                    Example of desired output structure (this is a generic example, do not use this content in your actual response):
                    
                    <cultural_analysis>
                    Potential cultural references:
                    DR. ""X"": This is an explicit mention of [cultural background] because [reasoning].
                    2. ""Y"": While this might imply [cultural background], it's not an explicit mention, so I won't tag it.
                    3. ""Z"": This is an explicit reference to [cultural background] because [reasoning].
                    
                    Planned tags:
                    - <[cultural background DR]>X</[cultural background DR]>
                    - <[cultural background 2]>Z</[cultural background 2]>
                    
                    I've confirmed that these tags meet the criteria for explicit cultural mentions. I've double-checked my tags for consistency and correct formatting. I've also ensured I'm only tagging explicit mentions without making assumptions.
                    </cultural_analysis>
                    
                    <tagged_post>
                    The <[cultural background DR]>X</[cultural background DR]> and Y walked down the street with their <[cultural background 2]>Z</[cultural background 2]> friend.
                    </tagged_post>
                    
                    Please proceed with your analysis and tagging of the given post.
                '''
                 }
            ]
        )
        result = response.content[0].text.strip()

        pd.set_option('display.max_colwidth', None)
        # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
        # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')

        match_finaltags = re.search(r'<tagged_post>(.*?)</tagged_post>', result, re.DOTALL)
        if match_finaltags:
            finaltags = match_finaltags.group(1).strip()
        else:
            print(f"Post: {index} : FINAL QUESTIONS not found")
            # print(result)
            finaltags = " "

        try:
            '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
            post = test_cases['Post'].iloc[index]
        except KeyError as e:
            print(f"Error: {e}")
            print("Check your DataFrame columns:", test_cases.columns)
            return []

        results.append({"Post": case, "Cultural Background": finaltags})
        print(f"*** Post: {index} : DONE ***")
        index = index + 1
    return results

def generate_socioeco(test_cases):
    """Test the prompt on the generated test cases."""
    results = []
    index = 0

    for case in test_cases['Post']:
        # with open("Examples_Part2.txt", "r") as file:
        #     examples = file.read()
        response = client.messages.create(
            model="claude-3-5-sonnet-20240620",
            max_tokens=4000,
            # system=prompt,
            messages=[
                {"role": "user", "content":
                 '''You are an AI language model tasked with identifying and tagging explicit mentions of socioeconomic status in a given text post. Your goal is to accurately recognize and tag clear references to socioeconomic status while avoiding assumptions or inferences based on limited or vague information. 
                    
                    Here is the post you need to analyze:
                    
                    <post>
                     {{''' + case + '''}} 
                    </post>
                    
                    Before we begin, let's define the socioeconomic status categories and provide example descriptors for each. Look for semantically similar attributes to the ones specified for each category.  
                    
                    DR. Low income:
                       - People experiencing homelessness
                       - Under-resourced
                       - Hardworking, working hard to make ends meet
                       - Experiencing food insecurity or food poverty
                       - People in emergency shelter or transitional housing
                    
                    2. Middle income:
                       - Middle class
                       - Blue collar workers
                       - Financially stable individuals or families
                       - Secure-income households
                       - Comfortably resourced communities
                       - Moderate-income earners
                       - Financially self-sufficient individuals
                    
                    3. High income:
                       - Financially affluent individuals or families
                       - Well-resourced communities
                       - Individuals with substantial financial security
                       - Economically privileged groups
                       - High-income earners
                    
                    Note: Avoid using offensive terminology such as ""The homeless,"" ""Inner city,"" ""Ghetto,"" ""Working poor,"" ""Poor,"" and ""Low-class"" when identifying socioeconomic status.
                    
                    Instructions:
                    
                    DR. Read the post carefully.
                    
                    2. Identify any explicit mentions of socioeconomic status that fit the defined categories and example descriptors.
                    
                    3. Tag these mentions using the following XML format: <[socioeconomic status]>mention</[socioeconomic status]>
                    
                    4. Use only the predefined categories for tagging: Low income, Middle income, High income.
                    
                    5. If no socioeconomic status is explicitly mentioned, return the original text without any tags.
                    
                    6. Before providing your final tagged post, conduct an analysis within <socioeconomic_analysis> tags. In this analysis:
                       a. List each sentence from the post, numbering them for reference.
                       b. For each sentence, list out all words and phrases that could potentially be related to socioeconomic status, even if they're not explicitly mentioned in the categories.
                       c. For each potential mention:
                          - Argue for its inclusion as an explicit socioeconomic status indicator.
                          - Argue against its inclusion as an explicit socioeconomic status indicator.
                          - Make a final decision on whether to include it and which category it belongs to, if any.
                       d. After analyzing all potential mentions, list the final set of mentions to be tagged, explaining your reasoning for each.
                       e. Double-check each identified mention against the criteria for explicitness and the predefined categories.
                       f. Confirm that your planned tags are consistent and correctly formatted.
                    
                    7. After your analysis, provide the tagged post within <tagged_post> tags.
                    
                    Example of desired output structure (this is a generic example, do not use this content in your actual response):
                    
                    <socioeconomic_analysis>
                    DR. ""Sentence one with struggling families"": 
                       Potential mention: ""struggling families""
                       Argument for inclusion: Could indicate low income status as it suggests financial difficulties.
                       Argument against inclusion: ""Struggling"" is vague and could refer to non-financial issues.
                       Decision: Do not include. While it suggests possible financial hardship, it's not an explicit mention of socioeconomic status.
                    
                    2. ""Sentence two with people experiencing homelessness"": 
                       Potential mention: ""people experiencing homelessness""
                       Argument for inclusion: Directly matches the example descriptor for Low income category.
                       Argument against inclusion: None.
                       Decision: Include as [Low income]. This is an explicit mention that directly matches our criteria.
                    
                    3. ""Sentence three with middle-class neighborhood"":
                       Potential mention: ""middle-class neighborhood""
                       Argument for inclusion: ""Middle-class"" is listed as an example descriptor for Middle income.
                       Argument against inclusion: None.
                       Decision: Include as [Middle income]. This is an explicit mention that matches our criteria.
                    
                    4. ""Sentence four with bourgeoisie"":
                       Potential mention: ""bourgeoisie""
                       Argument for inclusion: Listed as an example descriptor for High income category.
                       Argument against inclusion: None.
                       Decision: Include as [High income]. This is an explicit mention that matches our criteria.
                    
                    Final mentions to be tagged:
                    - ""people experiencing homelessness"" as [Low income]
                    - ""middle-class neighborhood"" as [Middle income]
                    - ""bourgeoisie"" as [High income]
                    
                    I've confirmed that these mentions meet the criteria for explicit socioeconomic status references and fit the predefined categories. Tags are consistent and correctly formatted.
                    </socioeconomic_analysis>
                    
                    <tagged_post>
                    Sentence one with struggling families. Sentence two with <[Low income]>people experiencing homelessness</[Low income]>. Sentence three with <[Middle income]>middle-class neighborhood</[Middle income]>. Sentence four with <[High income]>bourgeoisie</[High income]>.
                    </tagged_post>
                    
                    Please proceed with your analysis and tagging of the given post.'''
                 }
            ]
        )
        result = response.content[0].text.strip()

        pd.set_option('display.max_colwidth', None)
        # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
        # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')

        match_finaltags = re.search(r'<tagged_post>(.*?)</tagged_post>', result, re.DOTALL)
        if match_finaltags:
            finaltags = match_finaltags.group(1).strip()
        else:
            print(f"Post: {index} : FINAL QUESTIONS not found")
            # print(result)
            finaltags = " "

        try:
            '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
            post = test_cases['Post'].iloc[index]
        except KeyError as e:
            print(f"Error: {e}")
            print("Check your DataFrame columns:", test_cases.columns)
            return []

        num_cases = len(test_cases['Post'])
        results.append({"Post": case, "Socioeconomic Status": finaltags})
        print(f"*** Post: {index}/{num_cases}: DONE ***")
        index = index + 1
    return results


def generate_mental(test_cases):
    """Test the prompt on the generated test cases."""
    results = []
    index = 0

    for case in test_cases['Post']:
        # with open("Examples_Part2.txt", "r") as file:
        #     examples = file.read()
        try:
            response = client.messages.create(
                model="claude-3-5-sonnet-20240620",
                max_tokens=4000,
                # system=prompt,
                messages=[
                    {"role": "user", "content":
                        '''
                        You are an AI assistant specialized in identifying and tagging mentions of mental health conditions in text. Your task is to analyze a given post and add appropriate XML tags around any mentions of mental health conditions.
        
                        Here is the post you need to analyze:
        
                        <post>
                        {{''' + case + '''}}
                    </post>
    
                    Instructions:
                    1. Read the post carefully.
                    2. Identify any mentions of mental health conditions.
                    3. Tag each identified condition using XML tags.
                    4. If no mental health conditions are mentioned, return the original text without any tags.
    
                    The mental health conditions you should look for include, but are not limited to:
                    - Anxiety
                    - Depression
                    - Bipolar Disorder
                    - Schizophrenia
                    - Obsessive-Compulsive Disorder (OCD)
                    - Post-Traumatic Stress Disorder (PTSD)
                    - Generalized Anxiety Disorder (GAD)
                    - Eating Disorders
                    - Addiction/Substance Use Disorder
                    - Other (if you identify a condition not listed above)
    
                    Important: When tagging a mental health condition, use the name of the condition as the XML tag. For example:
                    - <Anxiety>severe anxiety</Anxiety>
                    - <Depression>clinical depression</Depression>
                    - <Bipolar_Disorder>bipolar disorder</Bipolar_Disorder>
    
                    If multiple mental health conditions are mentioned, tag each occurrence separately.
    
                    Before providing your final tagged post, conduct your analysis inside <mental_health_analysis> tags:
                    1. List out all potential mentions of mental health conditions in the post.
                    2. For each mention, provide a brief justification for why it might be considered a mental health condition.
                    3. Decide which mentions should be tagged and which should not, with a brief explanation for each decision.
                    It's OK for this section to be quite long.
    
                    After your analysis, provide the tagged post within <tagged_post> tags. If no mental health conditions are mentioned, simply return the original text without any tags, still within the <tagged_post> tags.
    
                    Example output structure:
    
                    <mental_health_analysis>
                    [Your analysis of the post, listing potential mentions, justifications, and tagging decisions]
                    </mental_health_analysis>
    
                    <tagged_post>
                    [The original post text with appropriate mental health condition tags added, or the original text if no conditions were mentioned]
                    </tagged_post>
    
                    Please proceed with your analysis and tagging of the given post.
    
                    '''
                     }
                ]
            )
            result = response.content[0].text.strip()

            pd.set_option('display.max_colwidth', None)
            # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
            # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')

            match_finaltags = re.search(r'<tagged_post>(.*?)</tagged_post>', result, re.DOTALL)
            if match_finaltags:
                finaltags = match_finaltags.group(1).strip()
            else:
                print(f"Post: {index} : FINAL QUESTIONS not found")
                # print(result)
                finaltags = " "

            try:
                '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
                post = test_cases['Post'].iloc[index]
            except KeyError as e:
                print(f"Error: {e}")
                print("Check your DataFrame columns:", test_cases.columns)
                return []

            results.append({"Post": case, "Mental Health Condition": finaltags})
            print(f"*** Post: {index} : DONE ***")
            index = index + 1
        except:
            print(f"*** Post: {index} : Exception Occurred ***")
            index = index +1

    return results


def save_gender_to_csv(results, filename):
    """Save the test results to a CSV file."""
    fieldnames = ["Post", "Gender"]
    with open(filename, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

def save_age_to_csv(results, filename):
    """Save the test results to a CSV file."""
    fieldnames = ["Post", "Age"]
    with open(filename, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

def save_socioeco_to_csv(results, filename):
    """Save the test results to a CSV file."""
    fieldnames = ["Post", "Socioeconomic Status"]
    with open(filename, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

def save_cultural_to_csv(results, filename):
    """Save the test results to a CSV file."""
    fieldnames = ["Post", "Cultural Background"]
    with open(filename, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

#
# def tag_list(output, filename, column):
#     for each in filename[column]:
#
#     tags = re.findall(r'<(.*?)>', output)
#     unique_tags = {tag.split()[0].strip('/') for tag in tags}
#     for tag in unique_tags:
#         print(tag)

def save_mental_to_csv(results, filename):
    """Save the test results to a CSV file."""
    fieldnames = ["Post", "Mental Health Condition"]
    with open(filename, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)


def demographic_tags(label):
    allFiles = ["clean_DR_reddit_train.csv", "clean_DR_reddit_valid.csv", "clean_dreaddit_dreaddit-train.csv", "clean_dreaddit_val.csv", "clean_Irf_train.csv", "clean_Irf_val.csv", "clean_MultiWD_train.csv", "clean_MultiWD_val.csv", "clean_SAD_train.csv", "clean_SAD_val.csv"]
    index = 6
    currFile = "/Users/batoolsmacbook/PycharmProjects/Post_Tagging/Cleaned Posts/" + allFiles[index]

    test_cases = pd.read_csv(currFile, usecols=["Post"])
    pd.set_option('display.max_colwidth', None)

    # results = generate_gender(test_cases)
    # save_gender_to_csv(results, "Tagged Posts/" + label+ "/gender(" + label+ ").csv")
    # print("Saved File - GENDER - " + allFiles[index])

    # results = generate_age(test_cases)
    # save_age_to_csv(results, "Tagged Posts/" + label+ "/age(" + label+ ").csv")
    # print("Saved File - AGE - "+ allFiles[index])
    #
    # results = generate_cultural(test_cases)
    # save_cultural_to_csv(results, "Tagged Posts/" + label+ "/cultural(" + label+ ").csv")
    # print("Saved File - CULTURAL BACKGROUND - " + allFiles[index])

    results = generate_socioeco(test_cases)
    save_socioeco_to_csv(results, "Tagged Posts/" + label+ "/socioeconomic(" + label + ").csv")
    print("Saved File - SOCIOECONOMIC STATUS - " + allFiles[index])


def mental_tags(label):
    allFiles = ["clean_DR_reddit_train.csv", "clean_MultiWD_train.csv"]
    index = 1
    currFile = "/Users/batoolsmacbook/PycharmProjects/Post_Tagging/Cleaned Posts/" + allFiles[index]

    test_cases = pd.read_csv(currFile, usecols=["Post"], nrows = 1000)
    pd.set_option('display.max_colwidth', None)

    results = generate_mental(test_cases)
    save_mental_to_csv(results, "Tagged Posts/" + label + "/mentalhealth(" + label + ").csv")
    print("Saved File - MENTAL HEALTH CONDITION - " + allFiles[index])

def append_column_to_csv(source_csv, column_name, target_csv="results(MultiWD).csv"):
    """
    Appends data from a specific column in `source_csv` as a new column in `target_csv`.

    Parameters:
    - source_csv (str): Path to the CSV file containing the column to extract.
    - column_name (str): The column name from which to extract data.
    - target_csv (str): Path to the CSV file where the column will be appended (default is 'results.csv').
    """
    # Check if the source CSV exists
    if not os.path.exists(source_csv):
        print(f"Error: Source file '{source_csv}' not found.")
        return

    # Read the source CSV
    source_df = pd.read_csv(source_csv)

    # Check if the specified column exists
    if column_name not in source_df.columns:
        print(f"Error: Column '{column_name}' not found in '{source_csv}'.")
        return

    # Extract the column data
    new_results = source_df[column_name].tolist()

    # Generate a unique column name for the target CSV
    # new_column_name = f"{column_name}_Run_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}"
    new_column_name = f"{column_name}"
    # Check if the target CSV exists
    if os.path.exists(target_csv):
        target_df = pd.read_csv(target_csv)  # Load existing target CSV
    else:
        target_df = pd.DataFrame()  # Create an empty DataFrame if the file doesn't exist

    # Ensure the length matches (pad with NaN if needed)
    max_len = max(len(target_df), len(new_results))
    target_df = target_df.reindex(range(max_len))  # Adjust index to accommodate new data

    # Append the extracted column data
    target_df[new_column_name] = pd.Series(new_results)

    # Save back to target CSV
    target_df.to_csv(target_csv, index=False)

    print(f"Column '{column_name}' from '{source_csv}' added as '{new_column_name}' in '{target_csv}'.")


def results_responses(test_cases):
    """Test the prompt on the generated test cases."""
    results = []
    index = 0

    for case in test_cases['Question with Few-Shot']:
        # with open("Examples_Part2.txt", "r") as file:
        #     examples = file.read()
        response = client.messages.create(
            model="claude-3-5-sonnet-20240620",
            max_tokens=4000,
            # system=prompt,
            messages=[{"role": "user", "content": case}]
        )
        result = response.content[0].text.strip()

        pd.set_option('display.max_colwidth', None)
        # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
        # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')


        try:
            '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
            post = test_cases['Question with Few-Shot'].iloc[index]
        except KeyError as e:
            print(f"Error: {e}")
            print("Check your DataFrame columns:", test_cases.columns)
            return []

        results.append({"Question with Few-Shot": case, "Response": result})
        print(f"*** Question: {index} : DONE ***")
        if index == 0:
            print(result)
        index = index + 1

    return results

def save_responses_to_csv(results, filename):
    """Save the test results to a CSV file."""
    fieldnames = ["Question Prompt", "Response"]
    with open(filename, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    print(f"Saved file to {filename}")


def results_responses_gemma(test_cases):
    """Test the prompt on the generated test cases."""

    client = genai.Client(api_key="AIzaSyA9LF7USvffrO4n-1NXTolpfzU1i8iGw9c")

    results = []
    index = 0

    # pipe = pipeline("text-generation", model="google/gemma-3-4b-it", device="cuda", torch_dtype=torch.bfloat16)

    for case in test_cases['Question Prompt']:

        model_id = "google/gemma-3-1b-it"
        tokenizer = AutoTokenizer.from_pretrained(model_id)
        model = AutoModelForCausalLM.from_pretrained(model_id, device_map=None)

        prompt = case
        pipe = pipeline("text-generation", model=model, tokenizer=tokenizer, device=-1)
        result = pipe(prompt, max_new_tokens=300)
        generated_text = result[0]["generated_text"]

        # Remove the prompt from the start of the generated text
        if generated_text.startswith(prompt):
            answer = generated_text[len(prompt):].strip()
        else:
            answer = generated_text.strip()

        # print(answer)

        # response = client.models.generate_content(
        #     model="gemma-2-4b-it",
        #     contents=[case]
        # )
        # print(response.text)




        result = answer
        pd.set_option('display.max_colwidth', None)
        # test_cases['Post'] = test_cases['Gender'].str.replace('\n', ' ')
        # test_cases['Test Case'] = test_cases['Test Case'].str.replace('\n', ' ')


        try:
            '''original_question = test_cases['Questions'].iloc[index]  # Use .iloc for positional indexing'''
            post = test_cases['Question Prompt'].iloc[index]
        except KeyError as e:
            print(f"Error: {e}")
            print("Check your DataFrame columns:", test_cases.columns)
            return []

        results.append({"Question Prompt": case, "Response": result})
        print(f"*** Question: {index} : DONE ***")
        if index == 0:
            print(result)
        index = index + 1

    return results



def main():
    # allFiles = ["clean_MultiWD_train.csv"]
    # label = "MultiWD"
    # for f in allFiles:
    #     curr_file = "/Users/batoolsmacbook/PycharmProjects/Post_Tagging/Cleaned Posts/" + f
    #     print("file: " + f + " found")
    #
    #     test_cases = pd.read_csv(curr_file, usecols=["Post"])
    #     pd.set_option('display.max_colwidth', None)
    #
    #     results = generate_socioeco(test_cases)
    #     save_socioeco_to_csv(results, "/Users/batoolsmacbook/PycharmProjects/Post_Tagging/Tagged Posts/MultiWD/socioeconomic(MultiWD-train).csv")
    #     print("Saved File - SOCIOECONOMIC STATUS - " + f)
    #



    prefix = "/Users/batoolsmacbook/PycharmProjects/Grouping/questioning prompts/original zero-shot/"
    # all_files = ['BBQ-few-shot_MHQA_explicit.csv', 'BBQ-few-shot_MHQA_original.csv',
    #              'BBQ-few-shot_MHQA_pre-response.csv', 'BBQ-few-shot_MHQA_roleplay.csv']
    all_files = ['MHQA_explicit.csv', 'MHQA_original.csv', 'MHQA_roleplay.csv', 'MHQA_pre-response.csv']
    for f in all_files:
        curr_file = prefix + f
        questions = pd.read_csv(curr_file, usecols=["Question Prompt"])
        results = results_responses_gemma(questions)
        new_file = "/Users/batoolsmacbook/PycharmProjects/Post_Tagging/Zero-Shot Results (Gemma)/results_" + f
        save_responses_to_csv(results, new_file)


if __name__ == "__main__":
    main()

