import ast
import csv
import re
import os
import random
import pandas as pd


def add_few_shot_to_csv(csv_path, txt_path, output_csv_path):
    # Step 1: Read the CSV file into a DataFrame
    df = pd.read_csv(csv_path)

    # Step 2: Read the contents of the few-shot .txt file
    with open(txt_path, "r", encoding="utf-8") as f:
        few_shot_text = f.read()

    # Step 3: Manually concatenate the few-shot text before the "Question Prompt" for each row
    for index, row in df.iterrows():
        df.at[index, 'Question with Few-Shot'] = few_shot_text + "\n" + row['Question Prompt']

    # Step 4: Save the modified DataFrame to a new CSV file
    df.to_csv(output_csv_path, index=False)


# Example usage
# add_few_shot_to_csv("input_file.csv", "few_shot.txt", "output_file.csv")

# Example usage
# add_few_shot_to_csv("input_file.csv", "few_shot.txt", "output_file.csv")

def main():
    path1 = '/Users/batoolsmacbook/PycharmProjects/Grouping/questioning prompts/original zero-shot/'
    zero_shots = ['MHQA_explicit.csv', 'MHQA_original.csv', 'MHQA_pre-response.csv', 'MHQA_roleplay.csv']
    txt_few_shot = "/Users/batoolsmacbook/PycharmProjects/BBQdataset/few-shot_BBQ.txt"
    path2 = '/Users/batoolsmacbook/PycharmProjects/Grouping/questioning prompts/BBQ few-shot/'
    for z in zero_shots:
        file = path1 + z
        output_file = path2 + "BBQ-few-shot_" + z
        add_few_shot_to_csv(file, txt_few_shot, output_file)

if __name__ == "__main__":
    main()